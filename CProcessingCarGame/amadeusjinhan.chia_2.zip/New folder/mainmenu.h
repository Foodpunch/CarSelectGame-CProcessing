#pragma once


void Main_Menu_Init(void);

void Main_Menu_Update(void);

void Main_Menu_Exit(void);

void StartGame(void);
//Exits the game (used in carlevel.c too)
extern void ExitGame(void);
void ShakeScreen(void);